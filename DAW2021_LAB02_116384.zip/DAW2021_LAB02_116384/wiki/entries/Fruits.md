
Although it is a widely used term, the word "fruit", in fact, is an unofficial designation attributed to the fruits of sweet taste. In other words, "fruit" does not exist in the botanical vocabulary.

Fruit (or fruit) is an integral part of some plants. As a rule, we can say that it is responsible for protecting and carrying seeds and that it can sometimes be used as food.

### Lists of fruits
- Apple
- Pear
- Orange
- Plum  
- Strawberry